from project.baked_food.bread import Bread
from project.baked_food.cake import Cake
from project.drink.tea import Tea
from project.drink.water import Water
from project.table.inside_table import InsideTable
from project.table.outside_table import OutsideTable


class Bakery:
    def __init__(self, name: str):
        self.name = name
        self.food_menu = []
        self.drinks_menu = []
        self.tables_repository = []
        self.total_income = 0

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        if value == "" or value == " ":
            raise ValueError("Name cannot be empty string or white space!")
        self.__name = value

    @staticmethod
    def find_item(item_obj, database):
        for item in database:
            if item.name == item_obj.name:
                return item

    @staticmethod
    def find_item_str(item_str, database):
        for item in database:
            if item.name == item_str:
                return item

    def find_table(self, number):
        for table in self.tables_repository:
            if table.table_number == number:
                return table

    def add_food(self, food_type: str, name: str, price: float):
        valid_types = ["Bread", "Cake"]
        if food_type == valid_types[0]:
            food = Bread(name, price)
            if self.find_item(food, self.food_menu):
                raise Exception(f"{food_type} {name} is already in the menu!")
            self.food_menu.append(food)
            return f"Added {name} ({food_type}) to the food menu"

        elif food_type == valid_types[1]:
            food = Cake(name, price)
            if self.find_item(food, self.food_menu):
                raise Exception(f"{food_type} {name} is already in the menu!")
            self.food_menu.append(food)
            return f"Added {name} ({food_type}) to the food menu"

    def add_drink(self, drink_type: str, name: str, portion: int, brand: str):
        valid_types = ["Tea", "Water"]
        if drink_type == valid_types[0]:
            drink = Tea(name, portion, brand)
            if self.find_item(drink, self.drinks_menu):
                raise Exception(f"{drink_type} {name} is already in the menu!")
            self.drinks_menu.append(drink)
            return f"Added {name} ({brand}) to the drink menu"

        elif drink_type == valid_types[1]:
            drink = Water(name, portion, brand)
            if self.find_item(drink, self.drinks_menu):
                raise Exception(f"{drink_type} {name} is already in the menu!")
            self.drinks_menu.append(drink)
            return f"Added {name} ({brand}) to the drink menu"

    def add_table(self, table_type: str, table_number: int, capacity: int):
        valid_types = ["InsideTable", "OutsideTable"]
        if table_type == valid_types[0]:
            table = InsideTable(table_number, capacity)
            if self.find_table(table_number):
                raise Exception(f"Table {table_number} is already in the bakery!")
            self.tables_repository.append(table)
            return f"Added table number {table_number} in the bakery"

        elif table_type == valid_types[1]:
            table = OutsideTable(table_number, capacity)
            if self.find_table(table_number):
                raise Exception(f"Table {table_number} is already in the bakery!")
            self.tables_repository.append(table)
            return f"Added table number {table_number} in the bakery"

    def reserve_table(self, number_of_people: int):
        table_obj = None
        for table in self.tables_repository:
            if not table.is_reserved and table.capacity >= number_of_people:
                table_obj = table
                break
        if table_obj:
            table_obj.reserve(number_of_people)
            return f"Table {table_obj.table_number} has been reserved for {number_of_people} people"
        else:
            return f"No available table for {number_of_people} people"

    def order_food(self, table_number: int, *food_names):
        table_obj = self.find_table(table_number)
        if not table_obj:
            return f"Could not find table {table_number}"
        have_list = []
        dont_have_list = []
        for item_str in food_names:
            item = self.find_item_str(item_str, self.food_menu)
            if item:
                have_list.append(item)
            else:
                dont_have_list.append(item_str)
        for item in have_list:
            table_obj.order_food(item)
        result = f"Table {table_number} ordered:\n"
        for item in have_list:
            result += f"{item}\n"

        result += f'{self.name} does not have in the menu:\n'
        for item in dont_have_list:
            result += f"{item}\n"
        return result.rstrip()

    def order_drink(self, table_number: int, *drinks_names):
        table_obj = self.find_table(table_number)
        if not table_obj:
            return f"Could not find table {table_number}"
        have_list = []
        dont_have_list = []
        for item_str in drinks_names:
            item = self.find_item_str(item_str, self.drinks_menu)
            if item:
                have_list.append(item)
            else:
                dont_have_list.append(item_str)
        for item in have_list:
            table_obj.order_drink(item)
        result = f"Table {table_number} ordered:\n"
        for item in have_list:
            result += f"{item}\n"

        result += f'{self.name} does not have in the menu:\n'
        for item in dont_have_list:
            result += f"{item}\n"
        return result.rstrip()

    def leave_table(self, table_number: int):
        table_obj = self.find_table(table_number)
        if table_obj:
            bill = table_obj.get_bill()
            self.total_income += bill
            table_obj.clear()
            result = f"Table: {table_number}\n" \
                     f"Bill: {bill:.2f}"
            return result

    def get_free_tables_info(self):
        result = ""
        for table in self.tables_repository:
            if not table.is_reserved:
                result += f"{table.free_table_info()}\n"
        return result

    def get_total_income(self):
        return f"Total income: {self.total_income:.2f}lv"
