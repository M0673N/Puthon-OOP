from project.pet_shop import PetShop
import unittest


class TestPetShop(unittest.TestCase):
    def setUp(self):
        self.shop = PetShop("test")

    def test_init__expect_data_to_be_set_correctly(self):
        self.assertEqual(self.shop.name, "test")
        self.assertEqual(self.shop.food, {})
        self.assertEqual(self.shop.pets, [])

    def test_add_food__quantity_less_than_zero_and_zero__expect_value_error(self):
        with self.assertRaises(ValueError) as context:
            self.shop.add_food("meat", -5)
        self.assertEqual(str(context.exception), 'Quantity cannot be equal to or less than 0')

        with self.assertRaises(ValueError) as context:
            self.shop.add_food("meat", 0)
        self.assertEqual(str(context.exception), 'Quantity cannot be equal to or less than 0')

    def test_add_food__quantity_above_zero__expect_increased_food_and_message(self):
        result = self.shop.add_food("meat", 10)
        self.assertEqual(result, "Successfully added 10.00 grams of meat.")
        self.assertEqual(self.shop.food, {"meat": 10})

    def test_add_pet__pet_not_in_pets__expect_to_add_pet_and_message(self):
        result = self.shop.add_pet("Tom")
        self.assertEqual(result, "Successfully added Tom.")
        self.assertEqual(self.shop.pets, ["Tom"])

    def test_add_pet__pet_in_pets__expect_exception(self):
        self.shop.add_pet("Tom")
        with self.assertRaises(Exception) as context:
            self.shop.add_pet("Tom")
        self.assertEqual(str(context.exception), 'Cannot add a pet with the same name')

    def test_feed_pet__missing_pet__expect_exception(self):
        with self.assertRaises(Exception) as context:
            self.shop.feed_pet("meat", "Jerry")
        self.assertEqual(str(context.exception), 'Please insert a valid pet name')

    def test_feed_pet__missing_food__expect_message(self):
        self.shop.add_pet("Tom")
        result = self.shop.feed_pet("meat", "Tom")
        self.assertEqual(result, 'You do not have meat')

    def test_feed_pet__low_food__expect_message(self):
        self.shop.add_pet("Tom")
        self.shop.add_food("meat", 10)
        result = self.shop.feed_pet("meat", "Tom")
        self.assertEqual(result, "Adding food...")
        self.assertEqual(self.shop.food, {"meat": 1010})

    def test_feed_pet__enough_food__expect_message(self):
        self.shop.add_pet("Tom")
        self.shop.add_food("meat", 1000)
        result = self.shop.feed_pet("meat", "Tom")
        self.assertEqual(result, "Tom was successfully fed")
        self.assertEqual(self.shop.food, {"meat": 900})

    def test_repr__expect_correct_message(self):
        self.shop.add_pet("Tom")
        self.shop.add_pet("Jerry")
        expected = f'Shop test:\n' \
                   f'Pets: Tom, Jerry'
        self.assertEqual(repr(self.shop), expected)
