from abc import ABC, abstractmethod


class BaseAquarium(ABC):
    @abstractmethod
    def __init__(self, name: str, capacity: int):
        self.name = name
        self.capacity = capacity
        self.decorations = []
        self.fish = []
        self.current_capacity = 0

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        if value == "":
            raise ValueError("Aquarium name cannot be an empty string.")
        self.__name = value

    def calculate_comfort(self):
        return sum(decoration.comfort for decoration in self.decorations)

    def add_fish(self, fish):
        if self.current_capacity == self.capacity:
            return "Not enough capacity."
        self.fish.append(fish)
        self.current_capacity += 1
        return f"Successfully added {fish.__class__.__name__} to {self.name}."

    def remove_fish(self, fish):
        self.fish.remove(fish)
        self.current_capacity -= 1

    def add_decoration(self, decoration):
        self.decorations.append(decoration)

    def feed(self):
        for fish in self.fish:
            fish.eat()

    def __str__(self):
        result = f"{self.name}:\n"
        if not self.fish:
            result += "Fish: none\n"
        else:
            result += f"Fish: {' '.join(fish.name for fish in self.fish)}\n"
        result += f"Decorations: {len(self.decorations)}\n" \
                  f"Comfort: {self.calculate_comfort()}"
        return result
