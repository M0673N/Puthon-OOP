from project.aquarium.freshwater_aquarium import FreshwaterAquarium
from project.aquarium.saltwater_aquarium import SaltwaterAquarium
from project.decoration.decoration_repository import DecorationRepository
from project.decoration.ornament import Ornament
from project.decoration.plant import Plant
from project.fish.freshwater_fish import FreshwaterFish
from project.fish.saltwater_fish import SaltwaterFish


class Controller:
    def __init__(self):
        self.decorations_repository = DecorationRepository()
        self.aquariums = []

    def add_aquarium(self, aquarium_type: str, aquarium_name: str):
        valid_types = ["FreshwaterAquarium", "SaltwaterAquarium"]
        if aquarium_type not in valid_types:
            return "Invalid aquarium type."
        elif aquarium_type == valid_types[0]:
            self.aquariums.append(FreshwaterAquarium(aquarium_name))
            return f"Successfully added {aquarium_type}."
        else:
            self.aquariums.append(SaltwaterAquarium(aquarium_name))
            return f"Successfully added {aquarium_type}."

    def add_decoration(self, decoration_type: str):
        valid_types = ["Ornament", "Plant"]
        if decoration_type not in valid_types:
            return "Invalid decoration type."
        elif decoration_type == valid_types[0]:
            self.decorations_repository.add(Ornament())
            return f"Successfully added {decoration_type}."
        else:
            self.decorations_repository.add(Plant())
            return f"Successfully added {decoration_type}."

    def find_aquarium(self, aquarium_name: str):
        for aquarium in self.aquariums:
            if aquarium.name == aquarium_name:
                return aquarium

    def find_decoration(self, decoration_type: str):
        for decoration in self.decorations_repository.decorations:
            if decoration.__class__.__name__ == decoration_type:
                return decoration

    def insert_decoration(self, aquarium_name: str, decoration_type: str):
        aquarium = self.find_aquarium(aquarium_name)
        decoration = self.find_decoration(decoration_type)
        if not decoration:
            return f"There isn't a decoration of type {decoration_type}."
        if aquarium and decoration:
            aquarium.add_decoration(decoration)
            self.decorations_repository.remove(decoration)
            return f"Successfully added {decoration_type} to {aquarium_name}."

    def add_fish(self, aquarium_name: str, fish_type: str, fish_name: str, fish_species: str, price: float):
        valid_types = ["FreshwaterFish", "SaltwaterFish"]
        aquarium_types = ["FreshwaterAquarium", "SaltwaterAquarium"]
        aquarium = self.find_aquarium(aquarium_name)
        if fish_type not in valid_types:
            return f"There isn't a fish of type {fish_type}."
        elif fish_type == valid_types[0] and aquarium.__class__.__name__ == aquarium_types[0]:
            result = aquarium.add_fish(FreshwaterFish(fish_name, fish_species, price))
            return result
        elif fish_type == valid_types[1] and aquarium.__class__.__name__ == aquarium_types[1]:
            result = aquarium.add_fish(SaltwaterFish(fish_name, fish_species, price))
            return result
        else:
            return "Water not suitable."

    def feed_fish(self, aquarium_name: str):
        aquarium = self.find_aquarium(aquarium_name)
        aquarium.feed()
        return f"Fish fed: {len(aquarium.fish)}"

    def calculate_value(self, aquarium_name: str):
        aquarium = self.find_aquarium(aquarium_name)
        value = sum(fish.price for fish in aquarium.fish) + sum(decoration.price for decoration in aquarium.decorations)
        return f"The value of Aquarium {aquarium_name} is {value:.2f}."

    def report(self):
        result = ""
        for aquarium in self.aquariums:
            result += f"{str(aquarium)}\n"
        return result.rstrip()
