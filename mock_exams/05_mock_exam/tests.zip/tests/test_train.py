import unittest

from project.train.train import Train


class TestTrain(unittest.TestCase):
    def setUp(self):
        self.train = Train("aaa", 10)

    def test_init__expect_pass(self):
        self.assertEqual(self.train.TRAIN_FULL, "Train is full")
        self.assertEqual(self.train.PASSENGER_EXISTS, "Passenger {} Exists")
        self.assertEqual(self.train.PASSENGER_NOT_FOUND, "Passenger Not Found")
        self.assertEqual(self.train.PASSENGER_ADD, "Added passenger {}")
        self.assertEqual(self.train.PASSENGER_ADD, "Added passenger {}")
        self.assertEqual(self.train.PASSENGER_REMOVED, "Removed {}")
        self.assertEqual(self.train.ZERO_CAPACITY, 0)
        self.assertEqual(self.train.name, "aaa")
        self.assertEqual(self.train.capacity, 10)
        self.assertEqual(self.train.passengers, [])

    def test_add__empty__expect_pass(self):
        self.assertEqual(self.train.add("aaa"), "Added passenger aaa")

    def test_add__full__expect_fail(self):
        self.train.passengers = ["a"] * 10
        with self.assertRaises(ValueError) as err:
            self.train.add("aaa")
        self.assertEqual("Train is full", str(err.exception))

    def test_add__existing__expect_fail(self):
        self.train.passengers = ["a"]
        with self.assertRaises(ValueError) as err:
            self.train.add("a")
        self.assertEqual("Passenger a Exists", str(err.exception))

    def test_remove__existing__expect_pass(self):
        self.train.passengers = ["a"]
        self.assertEqual(self.train.remove("a"), "Removed a")

    def test_remove__not_existing__expect_fail(self):
        with self.assertRaises(ValueError) as err:
            self.train.remove("a")
        self.assertEqual("Passenger Not Found", str(err.exception))


if __name__ == "__main__":
    unittest.main()
