from project.deliveries.drink import Drink
from project.deliveries.food import Food
from project.deliveries.product_repository import ProductRepository
from project.sales.customer import Customer
from project.sales.customer_repository import CustomerRepository


class Shop:
    def __init__(self):
        self.product_repository = ProductRepository()
        self.customer_repository = CustomerRepository()

    def deliver(self, product_type: str, name: str):
        types = ("Drink", "Food")
        if product_type == types[0]:
            return self.product_repository.add(Drink(name))
        elif product_type == types[1]:
            return self.product_repository.add(Food(name))

    def sell(self, customer_name: str, **shopping_list):
        customer = self.customer_repository.find(customer_name)
        if customer == "None":
            self.customer_repository.add(Customer(customer_name))
            customer = self.customer_repository.find(customer_name)
        result = []
        for item, amount in shopping_list.values():
            item_obj = self.product_repository.find(item)
            if item_obj != "None":
                if item_obj.quantity >= amount:
                    if item not in customer.products:
                        customer.products[item] = 0
                    customer.products[item] += amount
                    result.append(self.product_repository.decrease(item_obj, amount))
                    if item_obj.quantity == 0:
                        self.product_repository.products.remove(item_obj)

                elif item.obj.quantity < amount:
                    if item not in customer.products:
                        customer.products[item] = 0
                    customer.products[item] += item.obj.quantity
                    result.append(self.product_repository.decrease(item_obj, item_obj.quantity))
                    self.product_repository.products.remove(item_obj)

        if not result:
            return
        return "\n".join(result)
