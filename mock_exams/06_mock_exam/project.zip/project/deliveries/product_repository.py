class ProductRepository:
    def __init__(self):
        self.products = []

    def add(self, product):
        if product in self.products:
            raise ValueError(f"Product {product.name} already exists.")
        self.products.append(product)
        return f"Product {product.name} successfully added to inventory."

    def decrease(self, product, quantity: int):
        if product in self.products:
            product.quantity -= quantity
        return f"Left quantity of {product.name}: {product.quantity}"

    def find(self, product_name: str):
        for product in self.products:
            if product.name == product_name:
                return product
        return "None"
