from project.rooms.room import Room
from project.people.child import Child
from project.appliances.fridge import Fridge
import unittest


class TestRoom(unittest.TestCase):
    def setUp(self):
        self.room = Room("das", 100, 2)

    def test_init__expect_pass(self):
        self.assertEqual(self.room.family_name, "das")
        self.assertEqual(self.room.budget, 100)
        self.assertEqual(self.room.members_count, 2)
        self.assertEqual(self.room.children, [])
        self.assertEqual(self.room.expenses, 0)

    def test_expenses_prop__expect_pass(self):
        self.assertEqual(self.room.expenses, 0)

    def test_expenses_prop__expect_fail(self):
        with self.assertRaises(ValueError) as context:
            self.room.expenses = -1
        self.assertEqual("Expenses cannot be negative", str(context.exception))

    def test_calculate_expenses__expect_pass(self):
        self.room.calculate_expenses([Child(10, 10, 10)], [Fridge()])
        self.assertEqual(self.room.expenses, 31.2)


if __name__ == "__main__":
    unittest.main()
