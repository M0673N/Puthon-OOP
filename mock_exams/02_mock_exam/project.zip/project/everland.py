class Everland:
    def __init__(self):
        self.rooms = []

    def add_room(self, room):
        self.rooms.append(room)

    def get_monthly_consumptions(self):
        total = 0
        for room in self.rooms:
            total += room.expenses + room.room_cost
        return f"Monthly consumption: {total:.2f}$."

    def pay(self):
        result = []
        for room in self.rooms:
            price = room.room_cost + room.expenses
            if room.budget >= price:
                room.budget -= price
                result.append(f"{room.family_name} paid {price:.2f}$ and have {room.budget:.2f}$ left.")
            else:
                self.rooms.remove(room)
                result.append(f"{room.family_name} does not have enough budget and must leave the hotel.")
        return "\n".join(result)

    def status(self):
        people = 0
        for room in self.rooms:
            people += room.members_count
        result = f"Total population: {people}\n"

        for room in self.rooms:
            result += f"{room.family_name} with {room.members_count} members. " \
                      f"Budget: {room.budget:.2f}$, Expenses: {room.expenses:.2f}$\n"
            try:
                if room.children:
                    counter = 1
                    for child in room.children:
                        result += f"--- Child {counter} monthly cost: {child.cost * 30:.2f}$\n"
                        counter += 1
            except AttributeError:
                pass
            result += f"--- Appliances monthly cost: {room.appliances_cost:.2f}$\n"

        return result.rstrip()
