from project.supply.food_supply import FoodSupply
from project.supply.water_supply import WaterSupply


class Bunker:
    def __init__(self):
        self.survivors = []
        self.supplies = []
        self.medicine = []

    @property
    def food(self):
        result = []
        for supply in self.supplies:
            if supply.__class__.__name__ == "FoodSupply":
                result.append(supply)
        if not result:
            raise IndexError("There are no food supplies left!")
        return result

    @property
    def water(self):
        result = []
        for supply in self.supplies:
            if supply.__class__.__name__ == "WaterSupply":
                result.append(supply)
        if not result:
            raise IndexError("There are no water supplies left!")
        return result

    @property
    def painkillers(self):
        result = []
        for supply in self.supplies:
            if supply.__class__.__name__ == "Painkiller":
                result.append(supply)
        if not result:
            raise IndexError("There are no painkillers left!")
        return result

    @property
    def salves(self):
        result = []
        for supply in self.supplies:
            if supply.__class__.__name__ == "Salve":
                result.append(supply)
        if not result:
            raise IndexError("There are no salves left!")
        return result

    def add_survivor(self, survivor):
        if survivor in self.survivors:
            raise ValueError(f"Survivor with name {survivor.name} already exists.")
        else:
            self.survivors.append(survivor)

    def add_supply(self, supply):
        self.supplies.append(supply)

    def add_medicine(self, medicine):
        self.medicine.append(medicine)

    def heal(self, survivor, medicine_type):
        if survivor.needs_healing:
            for medicine in self.medicine[::-1]:
                if medicine.__class__.__name__ == medicine_type:
                    medicine.apply(survivor)
                    self.medicine.remove(medicine)
                    return f"{survivor.name} healed successfully with {medicine_type}"

    def sustain(self, survivor, sustenance_type):
        if survivor.needs_sustenance:
            for supply in self.supplies[::-1]:
                if supply.__class__.__name__ == sustenance_type:
                    supply.apply(survivor)
                    self.supplies.remove(supply)
                    return f"{survivor.name} sustained successfully with {sustenance_type}"

    def next_day(self):
        for survivor in self.survivors:
            survivor.needs -= survivor.age * 2
            FoodSupply().apply(survivor)
            WaterSupply().apply(survivor)
