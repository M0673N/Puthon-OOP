from project.medicine.medicine import Medicine


class Salve(Medicine):
    def __init__(self):
        super().__init__(50)
