import unittest
from project.factory.paint_factory import PaintFactory


class TestPaintFactory(unittest.TestCase):
    def setUp(self):
        self.factory = PaintFactory("Kitka", 10)

    def test_init__expect_correct_data_to_be_set(self):
        self.assertEqual(self.factory.name, "Kitka")
        self.assertEqual(self.factory.capacity, 10)
        self.assertEqual(self.factory.valid_ingredients, ["white", "yellow", "blue", "green", "red"])

    def test_can_add__too_many_items__expect_false(self):
        self.factory.ingredients = {"cups": 11}
        self.assertFalse(self.factory.can_add(1))

    def test_can_add__empty__expect_true(self):
        self.assertTrue(self.factory.can_add(1))

    def test_products__expect_pass(self):
        self.factory.ingredients = {"cups": 11}
        self.assertEqual(self.factory.ingredients, self.factory.products)

    def test_repr__expect_pass(self):
        self.factory.ingredients = {"cups": 5}
        expected_result = f"Factory name: Kitka with capacity 10.\n" \
                          f"cups: 5\n"
        actual_result = repr(self.factory)
        self.assertEqual(expected_result, actual_result)

    def test_add_ingredient__happy_case__expect_pass(self):
        self.factory.add_ingredient("white", 5)
        self.assertEqual({'white': 5}, self.factory.products)

    def test_add_ingredient__no_space__expect_value_error(self):
        with self.assertRaises(ValueError) as context:
            self.factory.add_ingredient("white", 50)
        self.assertEqual("Not enough space in factory", str(context.exception))

    def test_add_ingredient__invalid_product__expect_type_error(self):
        with self.assertRaises(TypeError) as context:
            self.factory.add_ingredient("plate", 5)
        self.assertEqual("Ingredient of type plate not allowed in PaintFactory", str(context.exception))

    def test_remove_ingredient__happy_case__expect_pass(self):
        self.factory.ingredients = {"cups": 5}
        self.factory.remove_ingredient("cups", 4)
        self.assertEqual({'cups': 1}, self.factory.products)

    def test_remove_ingredient__missing_product__expect_key_error(self):
        with self.assertRaises(KeyError) as context:
            self.factory.remove_ingredient("plate", 5)
        self.assertEqual("'No such ingredient in the factory'", str(context.exception))

    def test_remove_ingredient__too_many_items__expect_value_error(self):
        self.factory.ingredients = {"cups": 5}
        with self.assertRaises(ValueError) as context:
            self.factory.remove_ingredient("cups", 6)
        self.assertEqual("Ingredients quantity cannot be less than zero", str(context.exception))


if __name__ == "__main__":
    unittest.main()
