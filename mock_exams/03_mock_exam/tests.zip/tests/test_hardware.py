import unittest

from project.hardware.hardware import Hardware
from project.software.software import Software


class TestHardware(unittest.TestCase):
    def setUp(self):
        self.hardware = Hardware("aaa", "type", 100, 200)

    def test_init__expect_data_to_be_set_correctly(self):
        self.assertEqual(self.hardware.name, "aaa")
        self.assertEqual(self.hardware.type, "type")
        self.assertEqual(self.hardware.capacity, 100)
        self.assertEqual(self.hardware.memory, 200)
        self.assertEqual(self.hardware.software_components, [])

    def test_install__empty__expect_pass(self):
        self.hardware.install(Software("bbb", "av", 10, 20))
        self.hardware.install(Software("ccc", "av", 10, 20))
        self.assertEqual(len(self.hardware.software_components), 2)

    def test_install__full__expect_fail(self):
        with self.assertRaises(Exception) as err:
            self.hardware.install(Software("ddd", "av", 1000, 20))
        self.assertEqual("Software cannot be installed", str(err.exception))
        with self.assertRaises(Exception) as err:
            self.hardware.install(Software("ddd", "av", 10, 2000))
        self.assertEqual("Software cannot be installed", str(err.exception))

    def test_uninstall__expect_pass(self):
        soft = Software("bbb", "av", 10, 20)
        self.hardware.install(soft)
        self.hardware.uninstall(soft)
        self.assertEqual(len(self.hardware.software_components), 0)
