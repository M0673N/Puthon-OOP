class Hardware:
    def __init__(self, name, type_, capacity, memory):
        self.name = name
        self.type = type_
        self.capacity = capacity
        self.memory = memory
        self.software_components = []
        self.current_capacity = capacity
        self.current_memory = memory

    def install(self, software):
        if software.memory_consumption > self.current_memory or software.capacity_consumption > self.current_capacity:
            raise Exception("Software cannot be installed")
        self.software_components.append(software)
        self.current_capacity -= software.capacity_consumption
        self.current_memory -= software.memory_consumption

    def uninstall(self, software):
        self.software_components.remove(software)
