from project.hardware.heavy_hardware import HeavyHardware
from project.hardware.power_hardware import PowerHardware
from project.software.express_software import ExpressSoftware
from project.software.light_software import LightSoftware


class System:
    _hardware = []
    _software = []

    @staticmethod
    def register_power_hardware(name, capacity, memory):
        System._hardware.append(PowerHardware(name, capacity, memory))

    @staticmethod
    def register_heavy_hardware(name, capacity, memory):
        System._hardware.append(HeavyHardware(name, capacity, memory))

    @staticmethod
    def check_for_hardware(hardware_name):
        hardware = None
        for hardware_ in System._hardware:
            if hardware_.name == hardware_name:
                hardware = hardware_
                break
        if hardware is None:
            return "Hardware does not exist"
        return hardware

    @staticmethod
    def check_for_software(software_name):
        software = None
        for software_ in System._software:
            if software_.name == software_name:
                software = software_
        if software is None:
            return "Software does not exist"
        return software

    @staticmethod
    def try_to_install_software(hardware, software):
        try:
            hardware.install(software)
            System._software.append(software)
        except Exception:
            return "Software cannot be installed"

    @staticmethod
    def register_light_software(hardware_name, name, capacity_consumption, memory_consumption):
        hardware = System.check_for_hardware(hardware_name)
        if hardware == "Hardware does not exist":
            return "Hardware does not exist"
        software = LightSoftware(name, capacity_consumption, memory_consumption)
        return System.try_to_install_software(hardware, software)

    @staticmethod
    def register_express_software(hardware_name, name, capacity_consumption, memory_consumption):
        hardware = System.check_for_hardware(hardware_name)
        if hardware == "Hardware does not exist":
            return "Hardware does not exist"
        software = ExpressSoftware(name, capacity_consumption, memory_consumption)
        return System.try_to_install_software(hardware, software)

    @staticmethod
    def release_software_component(hardware_name, software_name):
        hardware = System.check_for_hardware(hardware_name)
        software = System.check_for_software(software_name)
        if hardware != "Hardware does not exist" and software != "Software does not exist":
            hardware.uninstall(software)
            System._software.remove(software)
        else:
            return "Some of the components do not exist"

    @staticmethod
    def analyze():
        result = f"System Analysis\n" \
                 f"Hardware Components: {len(System._hardware)}\n" \
                 f"Software Components: {len(System._software)}\n" \
                 f"Total Operational Memory: {sum([software.memory_consumption for software in System._software]):.0f} /" \
                 f" {sum([hardware.memory for hardware in System._hardware]):.0f}\n" \
                 f"Total Capacity Taken: {sum([software.capacity_consumption for software in System._software]):.0f} /" \
                 f" {sum([hardware.capacity for hardware in System._hardware]):.0f}"
        return result

    @staticmethod
    def system_split():
        result = ""
        for hardware in System._hardware:
            express_software = len([s for s in hardware.software_components
                                    if s.__class__.__name__ == 'ExpressSoftware'])
            light_software = len([s for s in hardware.software_components
                                  if s.__class__.__name__ == 'LightSoftware'])
            memory_consumption = sum([s.memory_consumption for s in hardware.software_components])
            capacity_consumption = sum([s.capacity_consumption for s in hardware.software_components])
            software_components = ', '.join([s.name for s in hardware.software_components])
            if not software_components:
                software_components = None
            result += f"Hardware Component - {hardware.name}\n" \
                      f"Express Software Components: {express_software}\n" \
                      f"Light Software Components: {light_software}\n" \
                      f"Memory Usage: {memory_consumption:.0f} / {hardware.memory:.0f}\n" \
                      f"Capacity Usage: {capacity_consumption:.0f} / {hardware.capacity:.0f}\n" \
                      f"Type: {hardware.type}\n" \
                      f"Software Components: {software_components}"
        return result.rstrip()
