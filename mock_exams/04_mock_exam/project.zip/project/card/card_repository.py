class CardRepository:
    def __init__(self):
        self.count = 0
        self.cards = []

    def check_for_card(self, card1):
        for card2 in self.cards:
            if card2.name == card1.name:
                return True
        return False

    def add(self, card):
        if self.check_for_card(card):
            raise ValueError(f"Card {card.name} already exists!")
        self.cards.append(card)
        self.count += 1

    def remove(self, card: str):
        if card == "":
            raise ValueError("Card cannot be an empty string!")
        for card2 in self.cards:
            if card2.name == card:
                self.cards.remove(card2)
                self.count -= 1
                return

    def find(self, name):
        for card in self.cards:
            if card.name == name:
                return card
