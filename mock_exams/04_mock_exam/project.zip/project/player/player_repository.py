class PlayerRepository:
    def __init__(self):
        self.count = 0
        self.players = []

    def check_for_player(self, player1):
        for player2 in self.players:
            if player2.username == player1.username:
                return True
        return False

    def add(self, player):
        if self.check_for_player(player):
            raise ValueError(f"Player {player.username} already exists!")
        self.players.append(player)
        self.count += 1

    def remove(self, player: str):
        if player == "":
            raise ValueError("Player cannot be an empty string!")
        for player2 in self.players:
            if player2.username == player:
                self.players.remove(player2)
                self.count -= 1
                return

    def find(self, username):
        for player2 in self.players:
            if player2.username == username:
                return player2
