from project.astronaut.astronaut_repository import AstronautRepository
from project.astronaut.biologist import Biologist
from project.astronaut.geodesist import Geodesist
from project.astronaut.meteorologist import Meteorologist
from project.planet.planet import Planet
from project.planet.planet_repository import PlanetRepository


class SpaceStation:
    def __init__(self):
        self.planet_repository = PlanetRepository()
        self.astronaut_repository = AstronautRepository()
        self.successful_missions = 0
        self.unsuccessful_missions = 0

    @staticmethod
    def create_the_right_astronaut(astronaut_type: str, name: str):
        if astronaut_type == "Biologist":
            return Biologist(name)
        if astronaut_type == "Geodesist":
            return Geodesist(name)
        if astronaut_type == "Meteorologist":
            return Meteorologist(name)

    def add_astronaut(self, astronaut_type: str, name: str):
        valid_types = ["Biologist", "Geodesist", "Meteorologist"]
        if astronaut_type not in valid_types:
            raise Exception("Astronaut type is not valid!")
        if self.astronaut_repository.find_by_name(name):
            return f"{name} is already added."
        astronaut = self.create_the_right_astronaut(astronaut_type, name)
        self.astronaut_repository.add(astronaut)
        return f"Successfully added {astronaut_type}: {name}."

    def add_planet(self, name: str, items: str):
        if self.planet_repository.find_by_name(name):
            return f"{name} is already added."
        split_items = items.split(", ")
        planet = Planet(name)
        for item in split_items:
            planet.items.append(item)
        self.planet_repository.add(planet)
        return f"Successfully added Planet: {name}."

    def retire_astronaut(self, name: str):
        astronaut = self.astronaut_repository.find_by_name(name)
        if not astronaut:
            raise Exception(f"Astronaut {name} doesn't exists!")
        self.astronaut_repository.remove(astronaut)
        return f"Astronaut {name} was retired!"

    def recharge_oxygen(self):
        for astronaut in self.astronaut_repository.astronauts:
            astronaut.increase_oxygen(10)

    def find_candidates(self):
        candidates = []
        for astronaut in self.astronaut_repository.astronauts:
            if astronaut.oxygen > 30:
                candidates.append(astronaut)
        candidates = sorted(candidates, key=lambda x: -x.oxygen)
        if len(candidates) > 5:
            candidates = candidates[:5]
        return candidates

    def explore(self, candidates, planet):
        success = False
        participated = 0
        for astronaut in candidates:
            if success:
                break
            participated += 1
            while astronaut.oxygen > 0:
                if len(planet.items) == 0:
                    success = True
                    break
                astronaut.backpack.append(planet.items.pop())
                astronaut.breathe()
        if success:
            self.successful_missions += 1
            return f"Planet: {planet.name} was explored. {participated} astronauts participated in collecting items."
        else:
            self.unsuccessful_missions += 1
            return "Mission is not completed."

    def send_on_mission(self, planet_name: str):
        planet = self.planet_repository.find_by_name(planet_name)
        if not planet:
            raise Exception("Invalid planet name!")
        candidates = self.find_candidates()
        if len(candidates) == 0:
            raise Exception("You need at least one astronaut to explore the planet!")
        result = self.explore(candidates, planet)
        return result

    def report(self):
        result = f"{self.successful_missions} successful missions!\n" \
                 f"{self.unsuccessful_missions} missions were not completed!\n" \
                 f"Astronauts' info:\n"
        for astronaut in self.astronaut_repository.astronauts:
            result += f"Name: {astronaut.name}\n" \
                      f"Oxygen: {astronaut.oxygen}\n"
            if len(astronaut.backpack) == 0:
                result += 'Backpack items: none\n'
            else:
                result += f"Backpack items: {', '.join(astronaut.backpack)}\n"
        return result.rstrip()


# a = SpaceStation()
# a.add_astronaut("Biologist", "name1")
# a.add_astronaut("Geodesist", "name2")
# a.add_astronaut("Meteorologist", "name3")
# a.add_astronaut("Biologist", "name4")
# a.add_astronaut("Biologist", "name5")
# a.add_planet("planet", "1, 2, 3, 4, 5, 6, 7, 8, 9, 10")
# a.send_on_mission("planet")
# print(a.report())
