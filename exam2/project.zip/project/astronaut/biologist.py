from project.astronaut.astronaut import Astronaut


class Biologist(Astronaut):
    initial_oxygen = 70

    def __init__(self, name: str):
        super().__init__(name, self.initial_oxygen)

    def breathe(self):
        self.oxygen -= 5
