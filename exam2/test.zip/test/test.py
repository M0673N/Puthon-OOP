from project.library import Library
import unittest


class TestLibrary(unittest.TestCase):
    def setUp(self):
        self.library = Library("aaa")

    def test_init__expect_data_to_be_set_correctly(self):
        self.assertEqual(self.library.name, "aaa")
        self.assertEqual(self.library.books_by_authors, {})
        self.assertEqual(self.library.readers, {})

    def test_name_setter__empty_name__expect_error(self):
        with self.assertRaises(ValueError) as error:
            self.library.name = ""
        self.assertEqual(str(error.exception), "Name cannot be empty string!")

    def test_name_setter__good_name__expect_name_to_be_set_correctly(self):
        self.library.name = "bbb"
        self.assertEqual(self.library.name, "bbb")

    def test_add_book__expect_correct_data(self):
        self.library.add_book("author", "title")
        self.assertEqual(self.library.books_by_authors, {"author": ["title"]})

    def test_add_reader__new__expect_correct_data(self):
        self.library.add_reader("Pesho")
        self.assertEqual(self.library.readers, {"Pesho": []})

    def test_add_reader__existing__expect_message(self):
        self.library.add_reader("Pesho")
        result = self.library.add_reader("Pesho")
        message = "Pesho is already registered in the aaa library."
        self.assertEqual(result, message)
        self.assertEqual(self.library.readers, {"Pesho": []})

    def test_rent_book__missing_reader__expect_message(self):
        self.library.add_book("author", "title")
        result = self.library.rent_book("Pesho", "author", "title")
        message = "Pesho is not registered in the aaa Library."
        self.assertEqual(result, message)

    def test_rent_book__missing_author__expect_message(self):
        self.library.add_reader("Pesho")
        result = self.library.rent_book("Pesho", "author", "title")
        message = "aaa Library does not have any author's books."
        self.assertEqual(result, message)

    def test_rent_book__missing_title__expect_message(self):
        self.library.add_reader("Pesho")
        self.library.add_book("author", "title")
        result = self.library.rent_book("Pesho", "author", "title2")
        message = """aaa Library does not have author's "title2"."""
        self.assertEqual(result, message)

    def test_rent_bool__correct_data__expect_data_to_be_set_correctly(self):
        self.library.add_reader("Pesho")
        self.library.add_book("author", "title")
        self.library.add_book("author", "title2")
        self.library.rent_book("Pesho", "author", "title")
        self.assertEqual(self.library.readers, {"Pesho": [{"author": "title"}]})
        self.assertEqual(self.library.books_by_authors, {"author": ["title2"]})


if __name__ == "__main__":
    unittest.main()
