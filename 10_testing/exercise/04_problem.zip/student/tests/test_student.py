import unittest
from project.student import Student


class TestStudent(unittest.TestCase):
    def setUp(self):
        self.student = Student("Pesho", {})

    def test_init__expect_data_to_be_set_correctly(self):
        self.assertEqual(self.student.name, "Pesho")
        self.assertEqual(self.student.courses, {})

    def test_init__no_courses__expect_data_to_be_set_correctly(self):
        student = Student("Pesho")
        self.assertEqual(student.name, "Pesho")
        self.assertEqual(student.courses, {})

    def test_enroll__course_in_courses__expect_pass(self):
        self.student.courses = {"Python": [1, 2]}
        result = self.student.enroll("Python", [3, 4])
        expected_result = {"Python": [1, 2, 3, 4]}
        actual_result = self.student.courses
        self.assertEqual(expected_result, actual_result)
        self.assertEqual("Course already added. Notes have been updated.", result)

    def test_enroll_course__new_course_and_add_course_notes_is_Y__expect_pass(self):
        result = self.student.enroll("Java", [3, 4], "Y")
        expected_result = {"Java": [3, 4]}
        actual_result = self.student.courses
        self.assertEqual(expected_result, actual_result)
        self.assertEqual("Course and course notes have been added.", result)

    def test_enroll_course__new_course_and_add_course_notes_is_empty__expect_pass(self):
        result = self.student.enroll("Java", [3, 4])
        expected_result = {"Java": [3, 4]}
        actual_result = self.student.courses
        self.assertEqual(expected_result, actual_result)
        self.assertEqual("Course and course notes have been added.", result)

    def test_enroll_course__new_course_and_add_course_notes_is_something_else__expect_pass(self):
        result = self.student.enroll("Java", [3, 4], "N")
        expected_result = {"Java": []}
        actual_result = self.student.courses
        self.assertEqual(expected_result, actual_result)
        self.assertEqual("Course has been added.", result)

    def test_add_notes__course_in_courses__expect_pass(self):
        self.student.courses = {"Python": [1, 2]}
        result = self.student.add_notes("Python", 3)
        expected_result = {"Python": [1, 2, 3]}
        actual_result = self.student.courses
        self.assertEqual(expected_result, actual_result)
        self.assertEqual("Notes have been updated", result)

    def test_add_notes__course_not_in_courses_expect_exception(self):
        with self.assertRaises(Exception) as context:
            self.student.add_notes("Python", 3)
        expected_result = "Cannot add notes. Course not found."
        actual_result = str(context.exception)
        self.assertEqual(expected_result, actual_result)

    def test_leave_course__existing_course__expect_pass(self):
        self.student.courses = {"Python": [1, 2]}
        result = self.student.leave_course("Python")
        expected_result = {}
        actual_result = self.student.courses
        self.assertEqual(expected_result, actual_result)
        self.assertEqual("Course has been removed", result)

    def test_leave_course__non_existing_course__expect_exception(self):
        with self.assertRaises(Exception) as context:
            self.student.leave_course("Python")
        expected_result = "Cannot remove course. Course not found."
        actual_result = str(context.exception)
        self.assertEqual(expected_result, actual_result)


if __name__ == '__main__':
    unittest.main()
