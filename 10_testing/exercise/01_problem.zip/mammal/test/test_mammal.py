import unittest
from project.mammal import Mammal


class TestMammal(unittest.TestCase):
    def setUp(self):
        self.test_mammal = Mammal("Tom", "cat", "meow")

    def test_init__expect_data_to_be_set_correctly(self):
        name = self.test_mammal.name
        type_ = self.test_mammal.type
        sound = self.test_mammal.sound
        kingdom = self.test_mammal._Mammal__kingdom
        expected_result = ("Tom", "cat", "meow", "animals")
        actual_result = (name, type_, sound, kingdom)
        self.assertEqual(expected_result, actual_result)

    def test_make_sound__expect_correct(self):
        expected_result = "Tom makes meow"
        actual_result = self.test_mammal.make_sound()
        self.assertEqual(expected_result, actual_result)

    def test_get_kingdom__expect_correct(self):
        expected_result = "animals"
        actual_result = self.test_mammal.get_kingdom()
        self.assertEqual(expected_result, actual_result)

    def test_info__expect_correct(self):
        expected_result = "Tom is of type cat"
        actual_result = self.test_mammal.info()
        self.assertEqual(expected_result, actual_result)


if __name__ == '__main__':
    unittest.main()
