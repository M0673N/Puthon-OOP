import unittest
from project.hero import Hero


class TestHero(unittest.TestCase):
    def setUp(self):
        self.hero = Hero("Tom", 1, 100.0, 20.0)

    def test_init__expect_data_to_be_set_correctly(self):
        expected_result = ("Tom", 1, 100.0, 20.0)
        actual_result = (self.hero.username, self.hero.level, self.hero.health, self.hero.damage)
        self.assertEqual(expected_result, actual_result)

    def test_battle__yourself__expect_exception(self):
        expected_result = "You cannot fight yourself"
        with self.assertRaises(Exception) as context:
            self.hero.battle(self.hero)
        self.assertEqual(expected_result, str(context.exception))

    def test_battle__not_enough_health__expect_value_error(self):
        enemy = Hero("Joe", 10, 100.0, 20.0)
        self.hero.health = -1
        expected_result = "Your health is lower than or equal to 0. You need to rest"
        with self.assertRaises(ValueError) as context:
            self.hero.battle(enemy)
        self.assertEqual(expected_result, str(context.exception))
        self.hero.health = 0
        expected_result = "Your health is lower than or equal to 0. You need to rest"
        with self.assertRaises(ValueError) as context:
            self.hero.battle(enemy)
        self.assertEqual(expected_result, str(context.exception))

    def test_battle__enemy_has_0_or_less_health__expect_value_error(self):
        enemy = Hero("Joe", 10, 0.0, 20.0)
        expected_result = "You cannot fight Joe. He needs to rest"
        with self.assertRaises(ValueError) as context:
            self.hero.battle(enemy)
        self.assertEqual(expected_result, str(context.exception))
        enemy = Hero("Joe", 10, -2.0, 20.0)
        expected_result = "You cannot fight Joe. He needs to rest"
        with self.assertRaises(ValueError) as context:
            self.hero.battle(enemy)
        self.assertEqual(expected_result, str(context.exception))

    def test_battle__correct_data__expect_draw(self):
        enemy = Hero("Joe", 6, 19.0, 20.0)
        expected_result = "Draw"
        actual_result = self.hero.battle(enemy)
        self.assertEqual(expected_result, actual_result)

    def test_battle__correct_data__expect_to_win(self):
        enemy = Hero("Joe", 1, 20.0, 20.0)
        expected_result = "You win"
        actual_result = self.hero.battle(enemy)
        self.assertEqual(expected_result, actual_result)
        self.assertEqual(2, self.hero.level)
        self.assertEqual(85, self.hero.health)
        self.assertEqual(25, self.hero.damage)

    def test_battle__correct_data__expect_to_lose(self):
        enemy = Hero("Joe", 10, 100.0, 20.0)
        expected_result = "You lose"
        actual_result = self.hero.battle(enemy)
        self.assertEqual(expected_result, actual_result)
        self.assertEqual(11, enemy.level)
        self.assertEqual(85, enemy.health)
        self.assertEqual(25, enemy.damage)

    def test_str__expect_correct_data(self):
        expected_result = f"Hero Tom: 1 lvl\n" \
                          f"Health: 100.0\n" \
                          f"Damage: 20.0\n"
        actual_result = str(self.hero)
        self.assertEqual(expected_result, actual_result)


if __name__ == '__main__':
    unittest.main()
