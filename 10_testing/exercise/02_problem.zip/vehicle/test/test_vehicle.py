import unittest
from project.vehicle import Vehicle


class TestVehicle(unittest.TestCase):
    def setUp(self):
        self.vehicle = Vehicle(50.0, 100.0)

    def test_init__expect_correct_values(self):
        fuel = self.vehicle.fuel
        capacity = self.vehicle.capacity
        horse_power = self.vehicle.horse_power
        fuel_consumption = self.vehicle.fuel_consumption
        expected_result = (50.0, 50.0, 100.0, 1.25)
        actual_result = (fuel, capacity, horse_power, fuel_consumption)
        self.assertEqual(expected_result, actual_result)

    def test_drive__not_enough_fuel_expect_exception(self):
        expected_result = "Not enough fuel"
        with self.assertRaises(Exception) as context:
            self.vehicle.drive(100)
        self.assertEqual(expected_result, str(context.exception))

    def test_drive__enough_fuel__expect_fuel_to_be_reduced_correctly(self):
        self.vehicle.drive(8)
        expected_result = 40.0
        actual_result = self.vehicle.fuel
        self.assertEqual(expected_result, actual_result)

    def test_refuel__too_much_fuel__expect_exception(self):
        expected_result = "Too much fuel"
        with self.assertRaises(Exception) as context:
            self.vehicle.refuel(100)
        self.assertEqual(expected_result, str(context.exception))

    def test_refuel__correct_amount_of_fuel__expect_fuel_to_be_added_correctly(self):
        self.vehicle.drive(8)
        self.vehicle.refuel(10)
        expected_result = 50.0
        actual_result = self.vehicle.fuel
        self.assertEqual(expected_result, actual_result)

    def test_str__expect_correct_info(self):
        expected_result = f"The vehicle has 100.0 " \
                          f"horse power with 50.0 fuel left and 1.25 fuel consumption"
        actual_result = str(self.vehicle)
        self.assertEqual(expected_result, actual_result)


if __name__ == '__main__':
    unittest.main()
